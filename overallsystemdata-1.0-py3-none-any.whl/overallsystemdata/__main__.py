from overallsystemdata.sysdata import printres

printres()
