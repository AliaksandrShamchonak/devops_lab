from sysdata import printres

printres()
